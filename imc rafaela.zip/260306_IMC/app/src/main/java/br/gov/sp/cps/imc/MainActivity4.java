package br.gov.sp.cps.imc;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity4 extends AppCompatActivity {
    private TextView txtValores;
    private TextView txtMensagem;
    private Button btnVoltar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main4);
        txtValores = findViewById(R.id.textViewValoresSobrepeso);
        txtMensagem = findViewById(R.id.textViewMensagemSobrePeso);
        btnVoltar = findViewById(R.id.btnVoltarSobrePeso);

        Intent intent = getIntent();
        String nome = intent.getStringExtra("nome");
        String peso = intent.getStringExtra("peso");
        String altura = intent.getStringExtra("altura");
        String imc = intent.getStringExtra("imc");
        String msg = intent.getStringExtra("msg");

        String valores = "Nome: " + nome + "\n" +
                         "Peso: " + peso + " kg\n" +
                         "Altura: " + altura + " m\n" +
                         "IMC: " + imc;
        
        txtValores.setText(valores);
        txtMensagem.setText(msg);

        btnVoltar.setOnClickListener(view -> finish());

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}